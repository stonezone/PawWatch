import Foundation

public enum PawWatchLog {
    public static let subsystem = "com.stonezone.pawWatch"
}

